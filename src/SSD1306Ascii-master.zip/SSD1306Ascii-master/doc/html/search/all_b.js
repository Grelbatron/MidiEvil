var searchData=
[
  ['nqueue',['nQueue',['../struct_ticker_state.html#a8b0175a247979bcc7cf03cd24da1aa09',1,'TickerState']]]
];

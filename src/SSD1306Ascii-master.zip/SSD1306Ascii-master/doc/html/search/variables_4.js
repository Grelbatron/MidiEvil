var searchData=
[
  ['font',['font',['../struct_ticker_state.html#adbf427e9ad58d994d4283fc1c5bd89c6',1,'TickerState']]]
];

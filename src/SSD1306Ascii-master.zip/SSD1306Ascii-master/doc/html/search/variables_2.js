var searchData=
[
  ['col',['col',['../struct_ticker_state.html#a2693c233a1195781c63e77251fb6e93a',1,'TickerState']]],
  ['coloffset',['colOffset',['../struct_dev_type.html#a9ffb262e6ccb78389abd291fd446c071',1,'DevType']]]
];
